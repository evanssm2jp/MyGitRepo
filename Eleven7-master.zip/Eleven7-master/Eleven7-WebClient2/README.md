#Todo

*   Dashboard sync with real stats (last supply && last income)
    *   get in api
    *   stats view dashboard

*   supply simu
    *   post in api
    *   services
    *   finish simu func
*   supply list
    *   table
    *   get api
    *   services
*   fix filter sale date filters by sending actual date
*   Filters in tables
