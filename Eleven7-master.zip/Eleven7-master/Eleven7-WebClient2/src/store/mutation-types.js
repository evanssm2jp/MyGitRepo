export const SET_SNACK = 'SET_SNACK'
export const OPEN_DRAWER = 'OPEN_DRAWER'
export const SET_DRAWER = 'SET_DRAWER'
