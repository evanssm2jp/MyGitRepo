# Eleven7
A full-stack project featuring a front-end &amp; a back-end working individually
